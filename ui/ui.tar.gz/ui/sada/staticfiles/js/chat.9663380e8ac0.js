/* Fair Trade Exchange chat — client.
   Mock /api/chat. Voice in (speech recognition) and out (speech synthesis) are progressive
   enhancements. Candidate questions for the chosen persona are offered up front. */
(function () {
  "use strict";
  const T = window.FTX;
  const transcript = document.getElementById("transcript");
  const suggestionsEl = document.getElementById("suggestions");
  const candidatesEl = document.getElementById("candidates");
  const candidateWrap = document.getElementById("candidate-wrap");
  const input = document.getElementById("input");
  const form = document.getElementById("composer");
  const langSel = document.getElementById("lang");
  const micBtn = document.getElementById("mic");
  const speakToggle = document.getElementById("speak-toggle");

  let language = T.language;

  function el(tag, cls, html) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html !== undefined) n.innerHTML = html;
    return n;
  }
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function addMessage(role, text, data) {
    const msg = el("div", "msg " + role);
    escapeHtml(text).split("\n").forEach(line => msg.appendChild(el("p", null, line || "&nbsp;")));
    if (data && data.pii_flagged && data.pii_flagged.length) {
      msg.appendChild(el("div", "pii-badge", "⚑ PII flagged for human review (not redacted): " + data.pii_flagged.join(", ")));
    }
    if (data && data.citations && data.citations.length) {
      const cites = el("div", "citations");
      data.citations.forEach(c => cites.appendChild(el("span", "cite " + (c.kind || ""), "🔗 " + escapeHtml(c.label))));
      msg.appendChild(cites);
    }
    const row = el("div", "row " + role);
    row.appendChild(el("div", "bubble-avatar", role === "user" ? "🧑" : "🌱"));
    row.appendChild(msg);
    transcript.appendChild(row);
    transcript.scrollTop = transcript.scrollHeight;
    return row;
  }
  function addSystem(text) {
    const msg = el("div", "msg system");
    escapeHtml(text).split("\n").forEach(line => msg.appendChild(el("p", null, line || "&nbsp;")));
    transcript.appendChild(msg);
    transcript.scrollTop = transcript.scrollHeight;
    return msg;
  }

  function renderSuggestions(list) {
    suggestionsEl.innerHTML = "";
    (list || []).forEach(s => {
      const b = el("button", "suggest", escapeHtml(s));
      b.type = "button";
      b.addEventListener("click", () => { input.value = s; send(); });
      suggestionsEl.appendChild(b);
    });
  }

  function renderCandidates(list) {
    candidatesEl.innerHTML = "";
    (list || []).slice(0, 2).forEach(q => {
      const b = el("button", "candidate", escapeHtml(q));
      b.type = "button";
      b.addEventListener("click", () => { input.value = q; send(); });
      candidatesEl.appendChild(b);
    });
  }

  function typing() {
    const r = addMessage("assistant", "…", null);
    r.dataset.typing = "1";
    return r;
  }

  const synth = window.speechSynthesis;
  const LOCALE = { en: "en-US", es: "es-ES", fr: "fr-FR", pt: "pt-BR", sw: "sw-KE", hi: "hi-IN" };
  function speak(text) {
    if (!speakToggle.checked || !synth) return;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = LOCALE[language] || "en-US";
    synth.speak(u);
  }

  let busy = false;
  async function send() {
    const message = input.value.trim();
    if (!message || busy) return;
    busy = true;
    if (candidateWrap) candidateWrap.style.display = "none";   // hide the starter strip after first turn
    addMessage("user", message, null);
    input.value = "";
    input.style.height = "auto";
    const pending = typing();
    try {
      const res = await fetch(T.chatUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": T.csrftoken },
        body: JSON.stringify({ message, language, persona_id: T.personaId }),
      });
      pending.remove();
      if (!res.ok) { addSystem("Something went wrong reaching the assistant. Please try again."); busy = false; return; }
      const data = await res.json();
      addMessage("assistant", data.text, data);
      renderSuggestions(data.suggestions);
      speak(data.text);
    } catch (e) {
      pending.remove();
      addSystem("Network hiccup — please try again.");
    }
    busy = false;
  }

  form.addEventListener("submit", e => { e.preventDefault(); send(); });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 150) + "px"; });
  input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });

  langSel.addEventListener("change", () => {
    language = langSel.value;
    addSystem("Language switched to " + langSel.options[langSel.selectedIndex].text + ". New answers will use it.");
  });

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SR) {
    const rec = new SR();
    rec.interimResults = true;
    let recording = false;
    micBtn.addEventListener("click", () => { if (recording) { rec.stop(); return; } rec.lang = LOCALE[language] || "en-US"; rec.start(); });
    rec.onstart = () => { recording = true; micBtn.classList.add("recording"); };
    rec.onend = () => { recording = false; micBtn.classList.remove("recording"); };
    rec.onresult = e => { let t = ""; for (let i = e.resultIndex; i < e.results.length; i++) t += e.results[i][0].transcript; input.value = t; };
    rec.onerror = () => { recording = false; micBtn.classList.remove("recording"); };
  } else { micBtn.style.display = "none"; }
  if (!synth) { speakToggle.closest("label").style.display = "none"; }

  // bootstrap
  addMessage("assistant", T.opening, null);
  renderCandidates(T.candidateQuestions);
})();
