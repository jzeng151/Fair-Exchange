/* Fair Trade Exchange chat — client.
   Talks to the mocked /api/chat. Voice in (Web Speech recognition) and out (speech synthesis) are
   progressive enhancements: if the browser lacks them, the mic/speak controls hide gracefully. */
(function () {
  "use strict";
  const T = window.FTX;
  const transcript = document.getElementById("transcript");
  const suggestionsEl = document.getElementById("suggestions");
  const input = document.getElementById("input");
  const form = document.getElementById("composer");
  const langSel = document.getElementById("lang");
  const micBtn = document.getElementById("mic");
  const speakToggle = document.getElementById("speak-toggle");
  const clearBtn = document.getElementById("clear-btn");

  let language = T.language;

  // ---- rendering --------------------------------------------------------
  function el(tag, cls, html) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html !== undefined) n.innerHTML = html;
    return n;
  }

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function addMessage(role, text, data) {
    const msg = el("div", "msg " + role);
    escapeHtml(text).split("\n").forEach(line => msg.appendChild(el("p", null, line || "&nbsp;")));
    if (data && data.pii_flagged && data.pii_flagged.length) {
      msg.appendChild(el("div", "pii-badge", "⚑ PII flagged for human review (not redacted): " + data.pii_flagged.join(", ")));
    }
    if (data && data.citations && data.citations.length) {
      const cites = el("div", "citations");
      data.citations.forEach(c => cites.appendChild(el("span", "cite " + (c.kind || ""), "🔗 " + escapeHtml(c.label))));
      msg.appendChild(cites);
    }
    transcript.appendChild(msg);
    transcript.scrollTop = transcript.scrollHeight;
    return msg;
  }

  function addSystem(text) { return addMessage("system", text, null); }

  function renderSuggestions(list) {
    suggestionsEl.innerHTML = "";
    (list || []).forEach(s => {
      const b = el("button", "suggest", escapeHtml(s));
      b.type = "button";
      b.addEventListener("click", () => { input.value = s; send(); });
      suggestionsEl.appendChild(b);
    });
  }

  function typing() {
    const m = addMessage("assistant", "…", null);
    m.dataset.typing = "1";
    return m;
  }

  // ---- speech output ----------------------------------------------------
  const synth = window.speechSynthesis;
  const LOCALE = { en: "en-US", es: "es-ES", fr: "fr-FR", pt: "pt-BR", sw: "sw-KE", hi: "hi-IN" };
  function speak(text) {
    if (!speakToggle.checked || !synth) return;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = LOCALE[language] || "en-US";
    u.rate = 1.0;
    synth.speak(u);
  }

  // ---- send -------------------------------------------------------------
  let busy = false;
  async function send() {
    const message = input.value.trim();
    if (!message || busy) return;
    busy = true;
    addMessage("user", message, null);
    input.value = "";
    input.style.height = "auto";
    const pending = typing();

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": T.csrftoken },
        body: JSON.stringify({ message, language, profile: T.profile }),
      });
      pending.remove();
      if (!res.ok) { addSystem("Something went wrong reaching the assistant. Please try again."); busy = false; return; }
      const data = await res.json();
      addMessage("assistant", data.text, data);
      renderSuggestions(data.suggestions);
      speak(data.text);
    } catch (e) {
      pending.remove();
      addSystem("Network hiccup — please try again.");
    }
    busy = false;
  }

  form.addEventListener("submit", e => { e.preventDefault(); send(); });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 140) + "px"; });
  input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });

  // ---- language ---------------------------------------------------------
  langSel.addEventListener("change", () => {
    language = langSel.value;
    addSystem("Language switched to " + langSel.options[langSel.selectedIndex].text + ". New answers will use it.");
  });

  // ---- voice input (Web Speech API) -------------------------------------
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SR) {
    const rec = new SR();
    rec.interimResults = true;
    let recording = false;
    micBtn.addEventListener("click", () => {
      if (recording) { rec.stop(); return; }
      rec.lang = LOCALE[language] || "en-US";
      rec.start();
    });
    rec.onstart = () => { recording = true; micBtn.classList.add("recording"); };
    rec.onend = () => { recording = false; micBtn.classList.remove("recording"); };
    rec.onresult = e => {
      let txt = "";
      for (let i = e.resultIndex; i < e.results.length; i++) txt += e.results[i][0].transcript;
      input.value = txt;
    };
    rec.onerror = () => { recording = false; micBtn.classList.remove("recording"); };
  } else {
    micBtn.style.display = "none";
  }
  if (!synth) { speakToggle.closest("label").style.display = "none"; }

  // ---- clear chat -------------------------------------------------------
  clearBtn.addEventListener("click", async () => {
    if (!confirm("Clear this conversation and start fresh with a new profile name?")) return;
    const res = await fetch("/api/reset", { method: "POST", headers: { "X-CSRFToken": T.csrftoken } });
    const data = await res.json();
    transcript.innerHTML = "";
    document.getElementById("persona-name").textContent = data.persona.name;
    document.getElementById("persona-role").textContent =
      data.persona.role_label + " · " + data.persona.region + ", " + data.persona.country;
    document.getElementById("avatar").textContent = data.persona.name.slice(0, 1);
    T.profile = data.persona.profile;
    if (synth) synth.cancel();
    bootstrap(data.opening, data.starter_suggestions);
  });

  // ---- bootstrap --------------------------------------------------------
  function bootstrap(opening, suggestions) {
    addMessage("assistant", opening, null);
    renderSuggestions(suggestions);
  }
  bootstrap(T.opening, T.starterSuggestions);
})();
